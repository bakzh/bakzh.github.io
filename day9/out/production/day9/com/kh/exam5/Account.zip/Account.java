package com.kh.exam5;

public class Account {
    private String accountName;     // 계좌 소유자명
    private long balance;           // 잔액
    private int accountNumber;      // 계좌번호

    private static int count;

    //생성자
    public Account(String accountName) {
        this.accountName = accountName;
    }

    //입금
    public void deposit(long money) {
        if (money > 40000) {
            System.out.println("1회 입금 한도는 4만원을 초과할 수 없습니다.");
        } else {
            this.balance += money;
        }
    }

    //출금
    public void withdraw(long money) {
        if ( 1 < money || this.balance - money < 40000) {
            System.out.println("1회 출금 한도는 4만원을 초과할 수 없습니다. ");
        } else {
            this.balance -= money;
        }
    }

    public String getAccountName() {
        return accountName;
    }

    public long getBalance() {
        return balance;
    }

    public int getAccountNumber() {
        return accountNumber;
    }

    public static int getCount() {
        return count;
    }

    @Override
    public String toString() {
        return "계좌{" +
                "계좌 소유자명='" + accountName + '\'' +
                ", 잔액=" + balance +
                ", 계좌번호=" + accountNumber +
                '}';
    }
}




