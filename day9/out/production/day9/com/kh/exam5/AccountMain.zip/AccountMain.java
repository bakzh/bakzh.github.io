package com.kh.exam5;

import java.lang.reflect.Array;
import java.util.Objects;
import java.util.Scanner;

public class AccountMain {
    public static void main(String[] args) {
        Account[] account = new Account[5];         // 개설할 수 있는 계좌 수
        Scanner scanner = new Scanner(System.in);

        int i = 0;
        int joinmember = 0;  //등록된 계좌 수수
        boolean stop = false;


        while (!stop) {
            System.out.println("1.신규 계좌 개설 2.계좌 폐지 3.입금 4.출금 5.계좌조회(개별) 6.계좌조회(전체) 7.종료(x)");
            System.out.print(">>");
            String menuNumber = scanner.nextLine();

            switch (menuNumber) {
                case "1":       //계좌 개설
                    System.out.println("이름을 입력하세요 : ");
                    String name = scanner.nextLine();
                    boolean flag = false;
                    for (i = 0; i < account.length; i++) {
                        if (account[i] == null) {
                            account[i] = new Account(name);
                            flag = true;
                            break;
                        }
                    }
                    if (!flag) {
                        System.out.println("더 이상 계좌를 만들 공간이 부족합니다.");
                    } else {
                        System.out.println(name + "님의 계좌가 개설되었습니다.");
                    }
                    break;
                case "2":       //폐지 , 단 1번(계좌 개설)전에는 사용불가.
                    System.out.println("이름을 입력해주세요");
                    String namedelete = scanner.nextLine();
                    int delete = 0;
                    for (i = 0; i < account.length; i++) {
                        if (account[i] != null) {
                            if (account[i].getAccountName().equals(namedelete)) {
                                joinmember--;
                                account[i] = null;
                                System.out.println("계좌를 삭제했습니다");
                            }
                        } else {
                            delete++;
                        }
                    }
                    break;
                case "3":      //입금 ,  단 1번(계좌 개설)전에는 사용불가.
                    System.out.println("입금할 계좌 번호를 입력해주세요");
                    String depositName = scanner.nextLine();


                    break;

                case "4":       //출금 ,  단 1번(계좌 개설)전에는 사용불가.

                    break;

                case "5":       //계좌조회(개별) ,  단 1번(계좌 개설)전에는 사용불가.

                    break;

                case "6":       //계좌조회(전체) ,  단 1번(계좌 개설)전에는 사용불가.

                    break;

                case "7":       //종료
                    System.out.println("종료!");
                    stop = true;
                    break;
                default:
                    System.out.println("메뉴(1~7)중에 선택해주세요 ㅠㅠ");
                    break;
            }
        }
    }
}
